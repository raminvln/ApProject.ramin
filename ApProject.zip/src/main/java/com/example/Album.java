package com.example;

import java.util.*;

public class Album {
    private String name;
    private User owner;
    private List<Picture> pictures = new ArrayList<>();

    public Album(String name,User owner) {
        this.name = name;
        this.owner = owner;
    }

    public String getName() {
        return name;
    }
    public User getOwner() {
        return owner;
    }

    // for changing album name
    public void setName(String name) {
        this.name = name;
    }

    public List<Picture> getPictures() {
        return pictures;
    }

    public void addPicture(Picture picture) {
        if (owner.getPictures().contains(picture) && !pictures.contains(picture) && owner.equals(picture.getOwner())) {
            pictures.add(picture);
            picture.getAlbums().add(this);
        }
    }

    public void removePicture(Picture picture) {
        if (pictures.contains(picture)) {
            pictures.remove(picture);
            picture.getAlbums().remove(this);
        }
    }
}
